<?php
$tarsConfig = include __DIR__ . '/../src/config/tars.php';
return $tarsConfig['proto'];
