<?php
return array(
    'appName' => 'PHPTest',
    'serverName' => 'PHPHttpServer',
    'objName' => 'obj',
);
