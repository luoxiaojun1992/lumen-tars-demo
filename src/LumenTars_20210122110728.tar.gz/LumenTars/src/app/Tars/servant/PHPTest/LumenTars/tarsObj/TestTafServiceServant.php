<?php

namespace App\Tars\servant\PHPTest\LumenTars\tarsObj;

interface TestTafServiceServant {
	/**
	 * @return int
	 */
	public function test();
}

