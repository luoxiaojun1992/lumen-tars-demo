<?php

namespace App\Services;

class DemoService
{
    public function ping()
    {
        return 'pong';
    }
}
