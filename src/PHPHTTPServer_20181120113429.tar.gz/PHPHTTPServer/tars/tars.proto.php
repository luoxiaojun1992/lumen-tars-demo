<?php
$laravelTarsTmpTarsConfig = include __DIR__ . '/../src/config/tars.php';
return $laravelTarsTmpTarsConfig['proto'];
