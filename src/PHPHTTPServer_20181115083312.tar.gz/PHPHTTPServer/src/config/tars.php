<?php

return [
    'registries' => [
//        [
//            'type' => 'kong',
//            'url' => env('KONG_UPSTREAM', ''),
//        ]
    ],

//    'tarsregistry' => env('TARS_REGISTRY', ''),

//    'log_level' => \Monolog\Logger::INFO,

//    'communicator_config_log_level' => 'INFO',
];
